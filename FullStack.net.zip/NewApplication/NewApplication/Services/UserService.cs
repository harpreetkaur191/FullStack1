﻿using DotNetAngular2;
using Microsoft.EntityFrameworkCore;
using NewApplication.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NewApplication.Services
{
    public class UserService : IUserService
    {
        private readonly DataContext _context;

        public UserService(DataContext context)
        {
            _context = context;
        }

        public async Task<List<Person>> GetPersons()
        {
            return await _context.Users.Include(p => p.Qualifications).ToListAsync();
        }

        public async Task<Person> GetPerson(Guid id)
        {
            return await _context.Users.Include(p => p.Qualifications)
                                       .FirstOrDefaultAsync(p => p.id == id);
        }

        public async Task<List<Person>> AddPersons(List<Person> persons)
        {
            foreach (var person in persons)
            {
                person.id = Guid.NewGuid();
                if (person.Qualifications != null && person.Qualifications.Any())
                {
                    foreach (var qualification in person.Qualifications)
                    {
                        qualification.ID = Guid.NewGuid();
                        qualification.PersonID = person.id;
                    }
                }
                _context.Users.Add(person);
            }

            await _context.SaveChangesAsync();
            return persons;
        }
        // public async Task<List<Qualification>> AddQualifications(Guid id, List<Qualification> qualifications)
        //{
        //    var person = await _context.Users.Include(p => p.Qualifications)
        //                                     .FirstOrDefaultAsync(p => p.id == id);

        //    if (person == null)
        //    {
        //        return null;
        //    }

        //    var newQualifications = new List<Qualification>();

        //    foreach (var qualification in qualifications)
        //    {
        //        if (!person.Qualifications.Any(q => q.QualificationName == qualification.QualificationName))
        //        {
        //            qualification.ID = Guid.NewGuid();
        //            qualification.PersonID = person.id;
        //            _context.UserQualifications.Add(qualification);
        //            newQualifications.Add(qualification);
        //        }
        //    }

        //    await _context.SaveChangesAsync();
        //    return newQualifications;
        //}

        public async Task UpdateEmployee(Guid guidId, Person updatedEmployee)
        {
            try
            {
                var existingEmployee = await _context.Users
                .Include(e => e.Qualifications)
                .FirstOrDefaultAsync(e => e.id == guidId);

                if (existingEmployee != null)
                {
                    existingEmployee.name = updatedEmployee.name;
                    existingEmployee.Gender = updatedEmployee.Gender;
                    existingEmployee.occupation = updatedEmployee.occupation;


                    if (updatedEmployee.Qualifications != null)
                    {
                        foreach (var qualification in updatedEmployee.Qualifications)
                        {
                            var existingQualification = existingEmployee.Qualifications
                                .FirstOrDefault(q => q.ID == qualification.ID);

                            if (existingQualification != null)
                            {
                                existingQualification.QualificationName = qualification.QualificationName;

                            }
                            else
                            {
                                qualification.ID = Guid.NewGuid();
                                qualification.PersonID = existingEmployee.id;
                                _context.UserQualifications.Add(qualification);
                                //existingEmployee.Qualifications.Add(qualification);
                            }
                        }
                    }

                    await _context.SaveChangesAsync();
                }
            }
            catch(System.Exception ex)
            {
                throw new Exception(ex.Message);
            }
            
        }


    }
}

