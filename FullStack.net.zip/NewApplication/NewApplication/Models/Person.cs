﻿using System.ComponentModel.DataAnnotations;

namespace NewApplication.Models
{
    public class Person
    {
        [Key]
        public Guid id { get; set; } 
        public string name { get; set; } 
        public string Gender { get; set; }

        public string occupation { get; set; }

        public ICollection<Qualification> Qualifications { get; set; }
        //[ConcurrencyCheck]
        //public byte[] RowVersion { get; set; } // This is the concurrency token
    }

}

  

