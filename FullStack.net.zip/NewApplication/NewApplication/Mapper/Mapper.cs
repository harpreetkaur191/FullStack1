﻿namespace NewApplication.Mapper
{
    public class Mapper
    {
    }
}
